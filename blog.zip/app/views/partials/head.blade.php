<title>Açık Teknoloji</title>
{{ HTML::Style('css/bootstrap.min.css') }}
{{ HTML::Style('css/theme.min.css') }}
{{ HTML::Script('js/jquery.min.js') }}
{{ HTML::Script('js/bootstrap.min.js') }}
<style>
@yield('extra.style')
</style>
@yield('extra.head')
