@extends('layouts.master')
@section('extra.head')
{{ HTML::Style('css/uikit.min.css') }}
{{ HTML::Script('js/uikit.min.js') }}
{{ HTML::Style('codemirror/lib/codemirror.css') }}
{{ HTML::Script('codemirror/lib/codemirror.js') }}
{{ HTML::Script('codemirror/mode/markdown/markdown.js') }}
{{ HTML::Script('codemirror/addon/mode/overlay.js') }}
{{ HTML::Script('codemirror/mode/xml/xml.js') }}
{{ HTML::Script('js/marked.js') }}

{{ HTML::Style('css/components/htmleditor.css') }}
{{ HTML::Script('js/components/htmleditor.js')}}
@stop
@section('content')
@if ($errors->has())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                {{ $error }}<br>
            @endforeach
        </div>
        @endif
{{ Form::open() }}
  {{ Form::textarea('content',$post->content,['class' => 'form-control','placeholder' => 'Gönderi','data-uk-htmleditor' => '{markdown:true}']) }}<br />
  {{ Form::submit('Gönderiyi düzenle',['class' => 'btn btn-lg btn-success'] )}}
{{ Form::close() }}
@stop
