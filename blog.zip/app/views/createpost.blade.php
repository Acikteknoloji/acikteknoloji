@extends('layouts.master')
@section('content')
@if ($errors->has())
        <div class="alert alert-danger">
            @foreach ($errors->all() as $error)
                {{ $error }}<br>
            @endforeach
        </div>
        @endif
{{ Form::open() }}
  {{ Form::text('title',null,['class' => 'form-control','placeholder' => 'Gönderi Başlığı']) }}<br />
  {{ Form::text('link',null,['class' => 'form-control','placeholder' => 'Link gönderisi ise link(http://www.google.com/)']) }}<br />
  {{ Form::textarea('content',null,['class' => 'form-control','placeholder' => 'Gönderi']) }}<br />
  {{ Form::submit('Gönderi Oluştur',['class' => 'btn btn-lg btn-success'] )}}
{{ Form::close() }}
@stop
